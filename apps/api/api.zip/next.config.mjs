/** @type {import('next').NextConfig} */
const nextConfig = {
    /* api: {
        bodyParser: {
            sizeLimit: '50mb',  // Set the max payload size to 50MB
        },
    }, */
};

export default nextConfig;
