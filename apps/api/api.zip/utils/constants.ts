export const SALT_ROUNDS = 10;
